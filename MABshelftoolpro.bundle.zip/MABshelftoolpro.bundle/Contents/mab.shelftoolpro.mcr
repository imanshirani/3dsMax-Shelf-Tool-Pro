macroScript ShelfToolPro category:"MYARTSBOX" tooltip:"Shelf Tool Pro"
(
    filein "mab.shelftoolpro.ms" 
)